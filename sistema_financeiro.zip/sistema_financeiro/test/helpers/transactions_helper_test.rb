require 'test_helper'

class TransactionsHelperTest < ActionView::TestCase
end
