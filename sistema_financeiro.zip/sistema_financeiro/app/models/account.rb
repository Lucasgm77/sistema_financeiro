class Account < ActiveRecord::Base
	belongs_to :pessoa
	has_secure_password
	validates :senha , presence: true
	has_many :transactions	
end
