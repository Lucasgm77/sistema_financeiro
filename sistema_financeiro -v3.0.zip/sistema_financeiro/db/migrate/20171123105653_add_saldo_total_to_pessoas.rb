class AddSaldoTotalToPessoas < ActiveRecord::Migration
  def change
    add_column :pessoas, :saldo_total, :decimal
  end
end
