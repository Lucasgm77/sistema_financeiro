class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception

  before_filter :set_search, :set_searchAccount, :set_searchTransaction

	def set_search
		@search = Pessoa.search(params[:q])
	end

	def set_searchAccount
		@searchAccount = Account.search(params[:q])
	end

	def set_searchTransaction
		@searchTransaction = Transaction.search(params[:q])
	end
	
end
