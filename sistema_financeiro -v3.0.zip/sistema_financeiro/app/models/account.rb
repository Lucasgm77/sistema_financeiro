class Account < ActiveRecord::Base
	belongs_to :pessoa
	has_many :transactions	
	after_save :atualiza_saldo_total

end
