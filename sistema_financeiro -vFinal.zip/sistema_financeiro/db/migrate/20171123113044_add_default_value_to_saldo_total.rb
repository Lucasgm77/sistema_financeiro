class AddDefaultValueToSaldoTotal < ActiveRecord::Migration
  def change
  	change_column :pessoas, :saldo_total, :decimal, default: 0
  end
end
